<?php
require 'firebase.php';
echo "Firebase is connected!";
?>
